package com.example.vanadiumviper24.acecardgolf;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;

public class GameSettings extends AppCompatActivity {

    private SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_settings);
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

    }

    @Override
    protected void onResume(){
        super.onResume();
        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        CheckBox ch1 = (CheckBox)findViewById(R.id.musicCheck);
        CheckBox ch2 = (CheckBox)findViewById(R.id.volumeCheck);
        if(ch1 != null && ch2 != null) {
            ch1.setChecked(sharedPref.getBoolean("musicSetting", true));
            ch2.setChecked(sharedPref.getBoolean("volumeSetting", true));
        }

    }

    public void onCheckBoxClick(View view){

        SharedPreferences.Editor edit = sharedPref.edit();
        boolean checked = ((CheckBox)view).isChecked();
        switch(view.getId()) {
            case R.id.musicCheck:
                edit.putBoolean("musicSetting", checked);
                edit.commit();
                break;
            case R.id.volumeCheck:
                edit.putBoolean("volumeSetting", checked);
                edit.commit();
                break;
            default:
                break;
        }
    }

    public static class SettingsFragment extends PreferenceFragment {

        @Override
        public void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.preferences);

        }
    }
}
