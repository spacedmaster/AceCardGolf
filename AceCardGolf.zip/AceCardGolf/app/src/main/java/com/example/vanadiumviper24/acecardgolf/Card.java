package com.example.vanadiumviper24.acecardgolf;

/**
 * Created by VanadiumViper24 on 3/7/2016.
 */
import android.widget.ImageView;

public class Card {
    //value numbers
    private static final int KING = 10;
    private static final int QUEEN = 10;
    private static final int JACK = 10;
    //private static final int JOKER = -2;
    private static final int ACE = 11;
    private static final int ACE_VALUE_TWO = 1;
    //suits
    private static final int HEARTS = 1;
    private static final int DIAMONDS = 2;
    private static final int CLUBS = 3;
    private static final int SPADES = 4;


    private int face_value;
    private boolean faceDown;
    private int suit;
    private int imageId;

    Card(int card_number, int suit){
        this.face_value = card_number;
        this.faceDown = true;
        this.suit = suit;
    }

    public int getFaceValue(){
        return face_value;
    }

    public int getSuit(){
        return suit;
    }

    public boolean getFaceDown(){
        return faceDown;
    }

    public void setFaceValue(int card_number){
        this.face_value = card_number;
    }

    public void setSuit(int suit){
        this.suit = suit;
    }

    public void setFaceDown(boolean faceDown){
        this.faceDown = faceDown;
    }


}
