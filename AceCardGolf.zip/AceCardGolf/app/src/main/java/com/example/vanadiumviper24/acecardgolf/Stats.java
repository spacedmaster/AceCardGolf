package com.example.vanadiumviper24.acecardgolf;

import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class Stats extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private SimpleCursorAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        mAdapter = new SimpleCursorAdapter(this, R.layout.list_item, null,
                new String[]{"usernames", "country", "wins", "losses", "ties", "totalGames"},
                new int[] {R.id.txtUsername, R.id.txtCountry, R.id.txtWins, R.id.txtLosses, R.id.txtGames}, 0);

        mAdapter.setViewBinder(new SimpleCursorAdapter.ViewBinder(){
            public boolean setViewValue(View view, Cursor cursor, int columnIndex){
               TextView tv = (TextView) view;
                tv.setText(cursor.getString(columnIndex) + "  ");
                return true;
            }
        });

        ListView listView = (ListView) findViewById(R.id.stats);
        listView.setAdapter(mAdapter);

        getLoaderManager().initLoader(1, null, this);
    }
    @Override
    public Loader<Cursor> onCreateLoader(int	id,	Bundle	args)	{
       String where = null;

        return	new CursorLoader(this,	StatsContentProvider.CONTENT_URI,
                new	String[]{"_id",	"usernames", "country", "wins", "losses", "ties", "totalGames"},
                            where,	null,	null);
    }
    @Override
    public	void	onLoadFinished(Loader<Cursor>	loader,	Cursor	cursor)	{
        mAdapter.swapCursor(cursor);
    }
    @Override
    public	void	onLoaderReset(Loader<Cursor>	loader)	{
        mAdapter.swapCursor(null);
    }


}
