package com.example.vanadiumviper24.acecardgolf;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;

public class StatsContentProvider extends ContentProvider {

    private DataBaseGolf theDB;

    private static final String AUTHORITY = "edu.psu.clr5566.stats";
    private static final String BASE_PATH = "stats";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/"
                                                    + BASE_PATH);
    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    private static final int STATS = 1;
    private static final int STATS_ID = 2;
    static {
        uriMatcher.addURI(AUTHORITY, BASE_PATH, STATS);
        uriMatcher.addURI(AUTHORITY, BASE_PATH + "/#", STATS_ID);
    }

    @Override
    public boolean onCreate(){
        theDB = DataBaseGolf.getInstance(getContext());

        return true;
    }

    @Override
    public int delete(@NonNull Uri uri, String selection, String[] selectionArgs) {
        int count;
        SQLiteDatabase db = theDB.getWritableDatabase();

        switch(uriMatcher.match(uri)){
            case STATS:
                count = db.delete("stats" , selection, selectionArgs);
                break;
            case STATS_ID:
                count = db.delete("stats" , appendIdToSelection(selection, uri.getLastPathSegment()),
                        selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    @Override
    public String getType(@NonNull Uri uri) {
        // TODO: Implement this to handle requests for the MIME type of the data
        // at the given URI.
        return null;
    }

    @Override
    public Uri insert(@NonNull Uri uri, ContentValues values) {
        // TODO: Implement this to handle requests to insert a new row.
        long id;
        SQLiteDatabase db = theDB.getWritableDatabase();

        switch(uriMatcher.match(uri)){
            case STATS:
                id = db.insert("stats" , null, values);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return Uri.parse(BASE_PATH + "/" + id);

    }



    @Override
    public Cursor query(@NonNull Uri uri, String[] projection, String selection,
            String[] selectionArgs, String sortOrder) {
        SQLiteDatabase db = theDB.getWritableDatabase();
        Cursor cursor;

        switch(uriMatcher.match(uri)){
            case STATS:
                cursor = db.query("stats" , projection, selection, selectionArgs, null, null, sortOrder);
                break;
            case STATS_ID:
                cursor = db.query("stats", projection, appendIdToSelection(selection, uri.getLastPathSegment()),
                        selectionArgs, null, null, sortOrder);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri );

        }
        cursor.setNotificationUri(getContext().getContentResolver(), uri);

        return cursor;

    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
            String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        int count;
        SQLiteDatabase db = theDB.getWritableDatabase();

        switch (uriMatcher.match(uri)){
            case STATS:
                count = db.update("stats", values, selection, selectionArgs);
                break;
            case STATS_ID:
                count = db.update("stats", values, appendIdToSelection(selection, uri.getLastPathSegment()),
                        selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;

    }
    public String appendIdToSelection(String selection, String sId) {
        int id = Integer.valueOf(sId);

        if(selection == null || selection.trim().equals(""))
            return "_ID = " + id;
        else
            return selection + " AND_ID = " + id;
    }


}
