package com.example.vanadiumviper24.acecardgolf;



import java.util.ArrayList;

/**
 * Created by VanadiumViper24 on 4/6/2016.
 */
public class Hand {

    private static final int BLACK_JACK = 21;

    private ArrayList<Card> hand;
    private int cardSum;
    private boolean bust;

    Hand(){
        hand = new ArrayList<Card>();
        cardSum = 0;
        bust = false;
    }

    //
    public void hit(Card hit_card){
        this.hand.add(hit_card);
        //may need to check if over 21
        if(this.cardSum + hit_card.getFaceValue() > 21){
            int ace_index = checkForAce();
            if(ace_index != -1){
                hand.get(ace_index).setFaceValue(1);
            }
            else{
                this.bust = true;
            }
        }
        this.cardSum += hit_card.getFaceValue();

//not finished
    }

    public int checkForAce(){
        for(int i = 0; i < this.hand.size(); i++){
            if(hand.get(i).getFaceValue() == 11){
                //return index of ace
                return i;
            }
        }
        //return -1 if no ace
        return -1;
    }


}
