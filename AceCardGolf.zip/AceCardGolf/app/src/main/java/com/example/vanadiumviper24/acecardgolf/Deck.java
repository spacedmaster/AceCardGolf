package com.example.vanadiumviper24.acecardgolf;

/**
 * Created by VanadiumViper24 on 3/9/2016.
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class Deck {

    //integers are mapped to card values in array in GameActivity
    private Stack<Integer> deck;


    Deck(){
        this.deck = new Stack<Integer>();
    }

    //deck push for simplicity
    public Integer push(Integer item){
        return this.deck.push(item);
    }

    public Integer pop(){
        return this.deck.pop();
    }

    public void shuffle(){
       ArrayList arrayList = new ArrayList<Integer>();
        for(int i = 0; i < 52; i++){
            arrayList.add(i);
        }
        Collections.shuffle(arrayList);
        this.deck.addAll(arrayList);
    }
}
