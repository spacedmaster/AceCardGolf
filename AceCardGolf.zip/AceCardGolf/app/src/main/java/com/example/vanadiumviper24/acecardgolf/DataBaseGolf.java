package com.example.vanadiumviper24.acecardgolf;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by VanadiumViper24 on 2/24/2016.
 */
public class DataBaseGolf extends SQLiteOpenHelper{

    public interface OnDBReadyListener {
        public void onDBReady(SQLiteDatabase theDB);
    }

    private static final String DATABASE_NAME = "acg.db";
    private static final int DATABASE_VERSION = 1;



    private static final String CREATE_SCHEMA = "CREATE TABLE stats ("+   //country will go in different table
            "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "usernames TEXT, wins INTEGER, losses INTEGER, ties INTEGER,"+
            "totalGames INTEGER, country TEXT)";

    private static final String DELETE_SCHEMA = "DROP TABLE IF EXISTS stats";

    private static DataBaseGolf theDb;
    private Context appContext;

    private DataBaseGolf(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        appContext = context.getApplicationContext();
    }

    public static synchronized DataBaseGolf getInstance (Context context){
        if (theDb == null){
            theDb = new DataBaseGolf(context.getApplicationContext());
        }
        return theDb;
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_SCHEMA);

        String[] usernames = {"ExampleUser","Spaced"};

        String[] countries =
                {"Cambodia","Germany"};
        int[] wins =
                {5, 6};
        int[] losses =
                {2,4};
        int[] ties =
                {1,0};
        int[] totalGames =
                {8,9};

        db.beginTransaction();
        ContentValues values = new ContentValues();

        for(int i = 0; i < ties.length; i++) {
            values.put("usernames", usernames[i]);
            values.put("country", countries[i]);
            values.put("wins", wins[i]);
            values.put("losses", losses[i]);
            values.put("ties", ties[i]);
            values.put("totalGames", totalGames[i]);
            db.insert("stats", null, values);
        }
        db.setTransactionSuccessful();
        db.endTransaction();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(DELETE_SCHEMA);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}